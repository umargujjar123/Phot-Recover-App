package com.example.data_recovery

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.data_recovery.databinding.ScanScreenBinding

class ScanScreen: AppCompatActivity() {
    lateinit var binding:ScanScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.scan_screen)
        binding.scanBtn.setOnClickListener(){
            startActivity(Intent(this,CardsScreen::class.java))
        }


    }
}